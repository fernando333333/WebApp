const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

const box = 20; // Dimensione di ogni cella del gioco
let snake = [{ x: 9 * box, y: 10 * box }];
let food = createFood();
let d;
let gameOver = false;
let gameInterval;
let score = 0;

document.getElementById('play-button').addEventListener('click', startGame);
document.getElementById('play-again-button').addEventListener('click', restartGame);

function startGame() {
    document.getElementById('play-button').style.display = 'none';
    document.getElementById('play-again-button').style.display = 'none';
    document.getElementById('gameOverText').style.display = 'none';
    document.getElementById('gameCanvas').style.display = 'block';
    score = 0;
    document.getElementById('score').innerText = 'Score: ' + score;
    document.addEventListener('keydown', direction);
    gameInterval = setInterval(draw, 180);
}

function restartGame() {
    snake = [{ x: 9 * box, y: 10 * box }];
    d = undefined;
    gameOver = false;
    clearInterval(gameInterval);
    startGame();
}

function draw() {
    if (gameOver) {
        clearInterval(gameInterval);
        document.getElementById('gameOverText').style.display = 'block';
        document.getElementById('play-again-button').style.display = 'block';
        return;
    }

    drawGrid();
    drawSnake();
    drawFood();
    moveSnake();
}

function drawGrid() {
    ctx.fillStyle = '#fafafa';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    for (let i = 0; i < canvas.width; i += box) {
        for (let j = 0; j < canvas.height; j += box) {
            ctx.strokeStyle = '#ddd';
            ctx.strokeRect(i, j, box, box);
        }
    }
}

function drawSnake() {
    for (let i = 0; i < snake.length; i++) {
        ctx.fillStyle = (i === 0) ? '#006600' : '#00cc00';
        ctx.fillRect(snake[i].x, snake[i].y, box, box);

        ctx.strokeStyle = '#003300';
        ctx.strokeRect(snake[i].x, snake[i].y, box, box);
    }
}

function drawFood() {
    ctx.fillStyle = 'red';
    ctx.fillRect(food.x, food.y, box, box);
}

function moveSnake() {
    let newHead = { x: snake[0].x, y: snake[0].y };

    if (d === 'LEFT') newHead.x -= box;
    if (d === 'UP') newHead.y -= box;
    if (d === 'RIGHT') newHead.x += box;
    if (d === 'DOWN') newHead.y += box;

    if (newHead.x === food.x && newHead.y === food.y) {
        score++;
        document.getElementById('score').innerText = 'Score: ' + score;
        food = createFood();
    } else {
        snake.pop();
    }

    snake.unshift(newHead);
    checkCollision();
}

function createFood() {
    return {
        x: Math.floor(Math.random() * 19 + 1) * box,
        y: Math.floor(Math.random() * 19 + 1) * box
    };
}

function checkCollision() {
    if (
        snake[0].x < 0 || snake[0].x >= canvas.width ||
        snake[0].y < 0 || snake[0].y >= canvas.height
    ) {
        gameOver = true;
    }

    for (let i = 1; i < snake.length; i++) {
        if (snake[0].x === snake[i].x && snake[0].y === snake[i].y) {
            gameOver = true;
        }
    }
}

function direction(event) {
    if (event.keyCode === 37 && d !== 'RIGHT') {
        d = 'LEFT';
    } else if (event.keyCode === 38 && d !== 'DOWN') {
        d = 'UP';
    } else if (event.keyCode === 39 && d !== 'LEFT') {
        d = 'RIGHT';
    } else if (event.keyCode === 40 && d !== 'UP') {
        d = 'DOWN';
    }
}
